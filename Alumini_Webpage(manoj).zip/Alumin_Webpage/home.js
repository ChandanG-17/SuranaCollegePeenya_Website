// gellary script
document.addEventListener('DOMContentLoaded', function () {
    var TrandingSlider = new Swiper('.tranding-slider', {
        effect: 'coverflow',
        grabCursor: true,
        centeredSlides: true,
        loop: true,  // Loop through the slides
        slidesPerView: 'auto',
        coverflowEffect: {
            rotate: 0,
            stretch: 0,
            depth: 100,
            modifier: 2.5,
        },
        autoplay: {
            delay: 2000, // Delay between transitions (in milliseconds)
            disableOnInteraction: false, // Keep autoplay running even when user interacts
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        }
    });
});

// counting alumini and students and chapters
// Function to animate counting
// Function to animate counting
function animateCount(elementId, start, end, duration) {
    const element = document.getElementById(elementId);
    const range = end - start;
    const increment = end > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / range));

    let current = start;
    const timer = setInterval(() => {
        current += increment;
        element.textContent = current+"+";
        if (current === end) {
            clearInterval(timer);
        }
    }, stepTime);
}

// Trigger the animations
window.onload = function () {
    animateCount("alumni-count", 14600, 15233, 1000);  // Faster alumni count (1 second for 30,000)
    animateCount("countries-count", 1, 60, 2000);  // 60 Countries
    animateCount("chapters-count", 1, 8, 2000);    // 8 Chapters
};
